IdentityCheck()
{
	
	//***************Verify Your Identity***********************
	
	web_add_header("Origin", "https://{URL_Secure}");

	/*Correlation comment - Do not change!  Original value='1AnwaAxJQ' Name ='verificationId' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=verificationId",
		"QueryString=$.payload.verificationId",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
		
	web_reg_find("Text=\"statusCode\":200", LAST);
			
	lr_start_transaction("BP01_T15_VerifyYourIdentity_OK");

	web_custom_request("register", 
		"URL=https://{URL_Secure}/ddc/public/api/green-id/register", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t90.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"title\":\"{CustTitle}\",\"firstName\":\"{CustFirstName}\",\"middleNames\":\"\",\"lastName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"email\":\"{CustEmail}\",\"address\":{\"country\":\"AU\",\"state\":\"{AddrState}\",\"streetName\":\"{AddrStreetName}\",\"flatNumber\":\"\",\"streetNumber\":\"{AddrStreetNum}\",\"suburb\":\"{AddrSuburb}\",\"postcode\":\"{AddrPostCode}\",\"streetType\":\"{AddrStreetType}\",\"townCity\":\"\"},\"extraData\":[{\"name\":\"dnb-credit-header-consent-given\",\"value\":\"true\"}]}", 
		LAST);

/*Correlation comment - Do not change!  Original value='92bb65d435b20cf1d17fbec9239b3ffa521eb22d' Name ='verificationToken' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=verificationToken",
		"QueryString=$.payload.verificationToken",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		"RequestUrl=*/token*",
		LAST);
		
	web_reg_find("Text=\"statusCode\":200", LAST);

	web_custom_request("token",
		"URL=https://{URL_Secure}/ddc/public/api/green-id/token?verificationId={verificationId}",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t91.inf",
		"Mode=HTML",
		"EncType=application/json",
		LAST);

	web_add_auto_header("Origin", "https://{URL_Secure}");
	web_add_auto_header("Sec-Fetch-Site", "cross-site");
	
	web_reg_save_param_ex(
		"ParamName=VerificationStatus",
		"LB=\"outcome\":\"",
		"RB=\"",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_find("Text=\"passed\"", LAST);

	web_custom_request("getsources",
		"URL=https://simpleui-au.vixverify.com/df/getsources",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/",
		"Snapshot=t94.inf",
		"Mode=HTML",
		"EncType=text/plain",
		"Body={\"accountId\":\"amp_au\",\"apiCode\":\"{API_Code}\",\"verificationToken\":\"{verificationToken}\",\"origin\":\"simpleui\"}",
		LAST);
	
	web_reg_find("Text=\"passed\"", LAST);

	web_custom_request("getfields",
		"URL=https://simpleui-au.vixverify.com/df/getfields",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/",
		"Snapshot=t95.inf",
		"Mode=HTML",
		"EncType=text/plain",
		"Body={\"accountId\":\"amp_au\",\"apiCode\":\"{API_Code}\",\"verificationToken\":\"{verificationToken}\",\"sourceId\":\"vicregodvs\",\"origin\":\"simpleui\"}",
		LAST);

	web_custom_request("log",
		"URL=https://simpleui-au.vixverify.com/df/log",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=https://{URL_Secure}/",
		"Snapshot=t98.inf",
		"Mode=HTML",
		"EncType=text/plain",
		"Body=[{\"message\":\"Setting overrides\",\"overrides\":\"sessionCompleteCallback sessionCancelledCallback enableBackButtonWarning enableCancelButton \",\"verificationId\":\"\",\"verificationToken\":\"\",\"accountId\":\"\",\"version\":\"\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:04:492\"},{\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36\",\"winHeight\":\"937\",\"docHeight\":\"5908\",\"winWidth\":\"1903\",\"docWidth\":\"1903\",\"url\":\"https://{URL_Secure}/ddc/public/ui/saver-account/\",\"message\":\"Client Info\",\"verificationId\":\"\",\"verificationToken\":\"\",\"accountId\":\"\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"datetime\":\"2021-07-20 20:46:04:494\"},{\"message\":\"Entered show\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"dateti"
		"me\":\"2021-07-20 20:46:05:813\"},{\"message\":\"Entered handleStartSuccess\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:06:350\"},{\"accountId\":\"amp_au\",\"verificationToken\":\"{verificationToken}\",\"attemptId\":\"\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36\",\"platform\":\"Windows\",\"message\":\"greenID Web - Start workflow point\",\"pointOfInterest\":\"HandleStartSuccess\",\"poiOrder\":\"10\",\"verificationId\":\"\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:06:351\"},{\"message\":\"dl is the next source, with order 0\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level"
		"\":\"INFO\",\"datetime\":\"2021-07-20 20:46:06:361\"},{\"source\":\"dl\",\"message\":\"Loading first source\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:06:361\"},{\"source\":\"dl\",\"message\":\"Entered getFields: \",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:06:361\"},{\"source\":\"vicregodvs\",\"message\":\"Entered showFields Form: vicregodvs\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:07:169\"},{\"message\":\"Entered initiateSourceyThings: vicregodvs\",\"verificationId\":\"\",\"verificationToken\":\"{verificationToken}"
		"\",\"accountId\":\"amp_au\",\"version\":\"21.0720.0_985f2e37_65\",\"logId\":\"nzwxbpi0\",\"level\":\"INFO\",\"datetime\":\"2021-07-20 20:46:07:279\"}]",
		LAST);

	lr_end_transaction("BP01_T15_VerifyYourIdentity_OK",LR_AUTO);

	lr_think_time(n);
	
	//***************Skip ID Check***********************

	web_add_auto_header("Sec-Fetch-Site", "same-origin");
	
	web_reg_find("Text=\"statusCode\":200", LAST);
	
	lr_start_transaction("BP01_T16_SkipIDCheck_OK");

	web_custom_request("save_8",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t99.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":\"{CustEmail}\",\"mobilePhone\":\"{CustMobile}\",\"homePhone\":\"{CustHomeNumber}\"},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber"
		"\":null,\"subBuildingNumber\":null,\"streetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":false,\"ok\":true,\"noTaxFileNumberReason\":{\"SelectedItem\":\"ExemptForTFN\",\"Query\":\"Exempt for TFN\"},\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"{{Address_PartialAddress}}\",\"{Address_PartialAddress}\"],\"countries\":[\"AUS\",\"AUS\"]"
		",\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":\"WIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"sourceOfFundsForAccount\":{\"SelectedItem\":\"FIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"reasonForOpeningAccount\":{\"SelectedItem\":\"EB\",\"Query\":\"Everyday banking (e.g. regular deposits and withdrawals for everyday expenses)\"}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":\"{verificationId}\",\"verificationStatus\":\"IN_PROGRESS\"}}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T16_SkipIDCheck_OK",LR_AUTO);

	lr_think_time(n);
	
	return 0;
}
