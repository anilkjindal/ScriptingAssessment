TaxDetails()
{
	
	//***************Answer TFN related questions and press OK***********************
	
	web_reg_find("Text=\"statusCode\":200",	LAST);

	lr_start_transaction("BP01_T12_TFN_Questions_OK");

	web_custom_request("save_5",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t84.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":\"{CustEmail}\",\"mobilePhone\":\"{CustMobile}\",\"homePhone\":\"{CustHomeNumber}\"},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query"
		"\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":false,\"ok\":true,\"noTaxFileNumberReason\":{\"SelectedItem\":\"ExemptForTFN\",\"Query\":\"Exempt for TFN\"}},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"{Address_PartialAddress}\",\"{{Address_PartialAddress}}\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T12_TFN_Questions_OK",LR_AUTO);

	lr_think_time(n);

	web_revert_auto_header("Origin");
	
	//***************Answer Foreign Tax Resident related questions and press OK***********************
	
	web_reg_find("Text={\"status\":\"pass\"}", LAST);
	
	lr_start_transaction("BP01_T13_ForeignTaxResident_Question_OK");

	web_url("individual", 
		"URL=https://{URL_Secure}/ddc/public/api/api-crs/AUS/individual?resCountry=AUS&postalCountry=AUS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", "https://{URL_Secure}");
	
	web_reg_find("Text=\"statusCode\":200",	LAST);

	web_custom_request("save_6",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t86.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":\"{CustEmail}\",\"mobilePhone\":\"{CustMobile}\",\"homePhone\":\"{CustHomeNumber}\"},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query"
		"\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":false,\"ok\":true,\"noTaxFileNumberReason\":{\"SelectedItem\":\"ExemptForTFN\",\"Query\":\"Exempt for TFN\"},\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"{Address_PartialAddress}\",\"{Address_PartialAddress}\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T13_ForeignTaxResident_Question_OK",LR_AUTO);

	lr_think_time(n);
	
	//***************Answer Extra Questions and Press OK***********************

	web_revert_auto_header("Origin");
	
	web_reg_find("Text=\"statusCode\":200",	LAST);
	
	lr_start_transaction("BP01_T14_FillExtraDetails_OK");

	web_custom_request("save_7",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t87.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":\"{CustEmail}\",\"mobilePhone\":\"{CustMobile}\",\"homePhone\":\"{CustHomeNumber}\"},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query"
		"\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":false,\"ok\":true,\"noTaxFileNumberReason\":{\"SelectedItem\":\"ExemptForTFN\",\"Query\":\"Exempt for TFN\"},\"change\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":\"pass\",\"addresses\":[\"{Address_PartialAddress}\",\"{Address_PartialAddress}\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":false},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":\"WIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"sourceOfFundsForAccount\":{\"SelectedItem\":\"FIE\",\"Query\":\"Income from employment (regular and/or bonus)\"},\"reasonForOpeningAccount\":{\"SelectedItem\":\"EB\",\"Query\":\"Everyday banking (e.g. regular deposits and withdrawals for everyday expenses)\"}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T14_FillExtraDetails_OK",LR_AUTO);

	lr_think_time(n);
	
	return 0;
}
