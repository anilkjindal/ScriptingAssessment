BankingPage()
{
	
	//***********Navigate to AMP Banking Page********************

	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_header("Sec-Fetch-User", "?1");
	web_add_header("Upgrade-Insecure-Requests", "1");
	
	web_reg_find("Text=Banking - AMP Bank", LAST);
	
	lr_start_transaction("BP01_T02_Navigate_To_BankingPage");

	web_url("banking", 
		"URL=https://{URL}/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL}/", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", "empty");
	web_add_auto_header("Sec-Fetch-Mode", "cors");
	web_add_header("X-Requested-With", "XMLHttpRequest");

/*Correlation comment - Do not change!  Original value='0ad46f504ad01c3048af5a1cde0656cf' Name ='userIdentifier' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=userIdentifier",
		"QueryString=$.userIdentifier",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	web_url("NetPromoterScore_2", 
		"URL=https://{URL}/wps/gws/NetPromoterScore?pageId=amp%3Abanking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL}/banking", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("X-Requested-With", "XMLHttpRequest");

	web_url("nps.html", 
		"URL=https://{URL}/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL}/banking", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("BP01_T02_Navigate_To_BankingPage",LR_AUTO);

	lr_think_time(n);	
	
	return 0;
}
