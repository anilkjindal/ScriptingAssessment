AMPSaversAccount()
{
	//*****Click 'Learn more' button under AMP Saver Account********
	
	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_header("Sec-Fetch-{CustLastName}", "?1");
	web_add_header("Upgrade-Insecure-Requests", "1");
	
	web_reg_find("Text=AMP Saver Account - AMP", LAST);
	
	lr_start_transaction("BP01_T04_Click_AMPSaverAccount_LearnMore");

	web_url("amp-saver-account", 
		"URL=https://{URL}/banking/savings-accounts/amp-saver-account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL}/banking/savings-accounts", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", "empty");
	web_add_auto_header("Sec-Fetch-Mode", "cors");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("NetPromoterScore_4",
		"URL=https://{URL}/wps/gws/NetPromoterScore?pageId=amp%3Abanking%3Asavings-accounts%3Aamp-saver-account&userIdentifier={userIdentifier}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL}/banking/savings-accounts/amp-saver-account",
		"Snapshot=t43.inf",
		"Mode=HTML",
		LAST);

	web_url("nps.html_3", 
		"URL=https://{URL}/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://{URL}/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t44.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	lr_end_transaction("BP01_T04_Click_AMPSaverAccount_LearnMore",LR_AUTO);

	lr_think_time(n);	
	
	return 0;
}
