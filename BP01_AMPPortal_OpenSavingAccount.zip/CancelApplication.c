CancelApplication()
{
	
	//***************Cancel Application*************************
	
	web_reg_find("Text=This form has been canceled successfully", LAST);
	
	lr_start_transaction("BP01_T18_Cancel_Application");

	web_custom_request("cancel",
		"URL=https://{URL_Secure}/ddc/public/api/forms/cancel?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t103.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={}",
		LAST);

	web_revert_auto_header("Origin");

	web_reg_find("Text=AMP Saver Account - AMP", LAST);
	
	web_add_auto_header("Sec-Fetch-Site", "same-site");
	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_header("Sec-Fetch-{CustLastName}", "?1");
	web_add_header("Upgrade-Insecure-Requests", "1");

	web_url("amp-saver-account_2", 
		"URL=https://{URL}/banking/savings-accounts/amp-saver-account", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL_Secure}/", 
		"Snapshot=t106.inf", 
		"Mode=HTML", 
		LAST);	
	
	web_add_auto_header("Sec-Fetch-Site", "same-origin");
	web_add_header("X-Requested-With", "XMLHttpRequest");

	web_url("nps.html_4", 
		"URL=https://{URL}/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://{URL}/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t109.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("BP01_T18_Cancel_Application",LR_AUTO);

	lr_think_time(n);
	
	return 0;
}
