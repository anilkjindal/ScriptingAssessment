StartSaverAccount()
{
	//*****Click 'Open an account' button**************************

	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_auto_header("Sec-Fetch-Site", "same-site");
	web_add_header("Sec-Fetch-{CustLastName}", "?1");
	web_add_header("Upgrade-Insecure-Requests", "1");
	
	web_reg_save_param_ex(
		"ParamName=ApiKey",
		"LB=ApiKey: \"",
		"RB=\"",
		"Ordinal=3",
		SEARCH_FILTERS,
		LAST);
	
	//F2x-L5D-7wW-EY4
	web_reg_save_param_ex(
		"ParamName=API_Code",
		"LB=password: \"",
		"RB=\"",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);
	
	web_reg_find("Text=<title>AMP Saver Account</title>", LAST);

	lr_start_transaction("BP01_T05_Click_Open_An_Account");

	web_url("saver-account", 
		"URL=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL}/banking/savings-accounts/amp-saver-account", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=<title>AMP Saver Account</title>", LAST);

	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_header("Upgrade-Insecure-Requests", "1");

	web_url("saver-account_2", 
		"URL=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", "cors");
	web_add_auto_header("Sec-Fetch-Dest", "empty");

	web_add_header("apiKey", "Bearer {ApiKey}");

	web_custom_request("usersession", 
		"URL=https://{URL_Secure}/services/secure/ddc/1.0.0/usersession", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("caller", "saver-account");

	web_custom_request("countries", 
		"URL=https://{URL_Secure}/ddc/public/api/refdata/countries", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		LAST);


	web_revert_auto_header("caller");

	web_add_header("apiKey", "Bearer {ApiKey}");

	web_custom_request("usersession_2", 
		"URL=https://{URL_Secure}/services/secure/ddc/1.0.0/usersession", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("BP01_T05_Click_Open_An_Account",LR_AUTO);

	lr_think_time(n);	
	
	return 0;
}
