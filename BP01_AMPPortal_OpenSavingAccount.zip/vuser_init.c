vuser_init()
{
	/*
	###########################################################################################################################################################
																		Documentation
	###########################################################################################################################################################
	
	# Created By: Anil Jindal
	# Creation Date: 21/07/2021
	# Last Updated By: Anil Jindal
	# Last Update Date: 21/07/2021
	
	# This script is created in Load Runner 12.60 version	

	# Business Process: Customer Navigates On AMP Web Portal to Create AMP Savers Account
	# Scipt Name: BP01_AMPPortal_OpenSavingAccount
	# Application: www.amp.com.au
	
	# User Journey:
		Step 1 - Go to www.amp.com.au
		Step 2 - Navigate to Banking Page
		Step 3 - Scroll down and under "Our banking accounts" click on Savings accounts
		Step 4 - Learn More - under AMP Saver Account
		Step 5 - Open an account
		Step 6 - Go through the application form and do everything up until the final submission (don't submit!)
	 
	# Input Parameters/Data
		 Server/Host Parameters
		 	- URL
		 	- URL_Secure
		 
		 Sample Format
		 	URL,URL_Secure
			www.amp.com.au,secure.amp.com.au
	 
	 	Customer Details
			- Addresses should be valid. Note, address information is case sensitive.
			- Phone Numbers should satisfy criteria of valid number
			
		Sample Format
			CustTitle,CustFirstName,CustLastName,CustDOB,CustAddress,CustEmail,CustMobile,CustHomeNumber,AddrStreetNum,AddrStreetName,AddrStreetType,AddrFullStreetType,AddrSuburb,AddrState,AddrPostCode
			Mr,Test,User,12/10/1984,20 Yellowbox Drive Point Cook VIC 3030,testuser@test.com,0412345678,0312345678,20,Yellowbox,DR,Drive,Point Cook,VIC,3030
	 
	 	 
		###########################################################################################################################################################
	 
	 */
		
	
	return 0;
}
