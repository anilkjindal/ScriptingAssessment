SavingsAccount()
{
	
	//*************Click on Saving Accounts***********************

	web_add_auto_header("Sec-Fetch-Mode", "navigate");
	web_add_auto_header("Sec-Fetch-Dest", "document");
	web_add_header("Sec-Fetch-{CustLastName}", "?1");
	web_add_header("Upgrade-Insecure-Requests", "1");

	web_reg_find("Text=High Interest Saving Accounts - AMP", LAST);
	
	lr_start_transaction("BP01_T03_Click_Savings_Account");

	web_url("savings-accounts", 
		"URL=https://{URL}/banking/savings-accounts", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{URL}/banking", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Sec-Fetch-Dest", "empty");
	web_add_auto_header("Sec-Fetch-Mode", "cors");
	web_add_auto_header("X-Requested-With", "XMLHttpRequest");

	web_url("NetPromoterScore_3",
		"URL=https://{URL}/wps/gws/NetPromoterScore?pageId=amp%3Abanking%3Asavings-accounts&userIdentifier={userIdentifier}",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL}/banking/savings-accounts",
		"Snapshot=t27.inf",
		"Mode=HTML",
		LAST);

	web_url("nps.html_2", 
		"URL=https://{URL}/wps/gws/com_amp_portal_nps/nps.html", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=https://{URL}/banking/savings-accounts", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("X-Requested-With");

	lr_end_transaction("BP01_T03_Click_Savings_Account",LR_AUTO);

	lr_think_time(n);
	
	return 0;
}
