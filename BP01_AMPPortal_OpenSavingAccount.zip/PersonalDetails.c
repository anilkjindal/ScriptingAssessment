PersonalDetails()
{

	//Variableles declaration for address search code
	
	char Temp1[40]="";
	char Temp2[40]="";	
	int n;
	int length;
	
	//***************Answer question "Who's this account for?"************************
	
	web_add_auto_header("DNT", "1");
	web_add_auto_header("Origin", "https://{URL_Secure}");
	web_add_auto_header("Sec-Fetch-Dest", "empty");
	web_add_auto_header("Sec-Fetch-Mode", "cors");
	web_add_auto_header("Sec-Fetch-Site", "same-origin");
	web_add_auto_header("sec-ch-ua", "\" Not;A Brand\";v=\"99\", \"Google Chrome\";v=\"91\", \"Chromium\";v=\"91\"");
	web_add_auto_header("sec-ch-ua-mobile", "?0");
	
	web_reg_find("Text=\"statusCode\":200", LAST);
	
	/*Correlation comment - Do not change!  Original value='b980e7b7-81c5-4c1c-9ba4-647d7706c09b' Name ='checkSecurityToken' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=checkSecurityToken",
		"QueryString=$.payload.meta.securityToken",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	/*Correlation comment - Do not change!  Original value='6998173915' Name ='formId' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=formId",
		"QueryString=$.payload.meta.id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	lr_start_transaction("BP01_T06_PersDetails_AccountIsFor_SelectJustMe");

	web_custom_request("save", 
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?&formName=SaverAccount", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t55.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":null,\"surName\":null,\"dateOfBirth\":null,\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":null,\"Query\":null},\"middleName\":null},\"contactDetails\":{\"emailAddress\":null,\""
		"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":null,\"query\":null},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":null,\"streetName\":null,\"streetType\":{\"SelectedItem\":null,\""
		"Query\":null},\"poBox\":null,\"suburb\":null,\"state\":{\"SelectedItem\":null,\"Query\":null},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":null,\"dpid\":null,\"barcode\":null,\"isInternational\":false},\"isItPoBox\":null},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\""
		"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[null,null],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\""
		"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		LAST);

	lr_end_transaction("BP01_T06_PersDetails_AccountIsFor_SelectJustMe",LR_AUTO);

	lr_think_time(n);
	
	
	//***************Fill "Tell us about yourself" section & click OK button************************
	
	web_reg_find("Text=\"statusCode\":200", LAST);
	
	lr_start_transaction("BP01_T07_PersDetails_AboutYourself_OK");

	web_custom_request("save_2",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t56.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":null,\"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":null,\"query\":null},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":null,\"streetName\":null,\"s"
		"treetType\":{\"SelectedItem\":null,\"Query\":null},\"poBox\":null,\"suburb\":null,\"state\":{\"SelectedItem\":null,\"Query\":null},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":null,\"dpid\":null,\"barcode\":null,\"isInternational\":false},\"isItPoBox\":null},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[null,null],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificati"
		"onId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T07_PersDetails_AboutYourself_OK", LR_AUTO);

	lr_think_time(n);
	
	
	//***************Enter Address in the Address Box************************

	web_revert_auto_header("Origin");
	web_add_auto_header("caller", "saver-account");
	
	strcpy(Temp1, lr_eval_string("{CustAddress}"));
	
	length=strlen(Temp1);
	
	for(n=1; n <= length; n++)
	{
		strncpy(Temp2,Temp1,n);
		
		//lr_output_message("Address is %s and number of characters are %d", Temp2, n);
		lr_save_string(Temp2,"AddressEntered");
		
		//Address Search Request
		
		web_reg_save_param_regexp(
			"ParamName=Address_Moniker",
			"RegExp=\"Moniker\":\"(.*?)\",\"PartialAddress\":\"(.*?)\"",
			"NotFound=warning",
			"Group=1",
			"Ordinal=1",
			SEARCH_FILTERS,
			LAST);
	
		web_reg_save_param_regexp(
			"ParamName=Address_PartialAddress",
			"RegExp=\"Moniker\":\"(.*?)\",\"PartialAddress\":\"(.*?)\"",
			"NotFound=warning",
			"Group=2",
			"Ordinal=1",
			SEARCH_FILTERS,
			LAST);
		
		lr_start_transaction("BP01_T08_PersDetails_SearchAddressRequest");
		
		web_custom_request("AddressSearch", 
		"URL=https://{URL_Secure}/ddc/public/api/qas/doSearch/AUS/{AddressEntered}?residentialOnly=true", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t57.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);
		
		lr_end_transaction("BP01_T08_PersDetails_SearchAddressRequest",LR_AUTO);
	}
	
	//***************Select An Address From Dropdown************************
	
	
	//1301011100301010010222333131231022213
	web_reg_save_param_ex(
		"ParamName=BarCode",
		"LB=\"AUSBAR.\":\"",
		"RB=\"",
		"Ordinal=1",
		SEARCH_FILTERS,
		LAST);
		
	/*Correlation comment - Do not change!  Original value='40933128' Name ='DPID/DID' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=DPID_DID",
		"QueryString=$.payload.DDC.DPID/DID",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

	lr_start_transaction("BP01_T09_PersDetails_GetAddress");
			
	web_custom_request("SelectAddress", 
		"URL=https://{URL_Secure}/ddc/public/api/qas/doGetAddress/AUS/{Address_Moniker}?partialAddress={Address_PartialAddress}", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t81.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		LAST);

	lr_end_transaction("BP01_T09_PersDetails_GetAddress",LR_AUTO);

	lr_think_time(n);
	
	//***************After selecting address click OK***********************
	
	web_revert_auto_header("caller");
	web_add_auto_header("Origin", "https://{URL_Secure}");
	
	web_reg_find("Text=statusCode\":200", LAST);
		
	lr_start_transaction("BP01_T10_PersDetails_Address_OK");

	web_custom_request("save_3",
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/",
		"Snapshot=t82.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\"emailAddress\":null,\"mobilePhone\":null,\"homePhone\":null},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"st"
		"reetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"{Address_PartialAddress}\",\"{Address_PartialAddress}\"],\"countries\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Quer"
		"y\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}",
		LAST);

	lr_end_transaction("BP01_T10_PersDetails_Address_OK",LR_AUTO);

	lr_think_time(n);	
	
	web_reg_find("Text=\"statusCode\":200",	LAST);
	
	//***************Fill contact details and click OK***********************

	lr_start_transaction("BP01_T11_EnterContactDetails_OK");

	web_custom_request("save_4", 
		"URL=https://{URL_Secure}/ddc/public/api/forms/save?formId={formId}&checkSecurityToken={checkSecurityToken}&formName=SaverAccount&checkDob={CustDOB}&checkName={CustLastName}", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{URL_Secure}/ddc/public/ui/saver-account/", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"welcome\":{\"tags\":\"[\\\"customer\\\"]\",\"continueApplication\":null,\"newApplication\":true},\"newOrExistingCustomer\":{\"customerType\":\"New\"},\"captcha\":{},\"adviser\":{},\"singleOrJoint\":{\"applicationType\":\"Individual\"},\"applicants\":[{\"personalDetails\":{\"basicInfo\":{\"firstName\":\"{CustFirstName}\",\"surName\":\"{CustLastName}\",\"dateOfBirth\":\"{CustDOB}\",\"scvId\":null,\"hasAdpId\":null,\"title\":{\"SelectedItem\":\"{CustTitle}\",\"Query\":\"{CustTitle}\"},\"middleName\":\"\"},\"contactDetails\":{\""
		"emailAddress\":\"{CustEmail}\",\"mobilePhone\":\"{CustMobile}\",\"homePhone\":\"{CustHomeNumber}\"},\"address\":{\"addresses\":{\"isAnyAddressInternational\":false,\"residentialAddress\":{\"isManualSearch\":false,\"search\":{\"selectedItem\":\"{Address_Moniker}\",\"query\":\"{Address_PartialAddress}\"},\"manualAddress\":{\"country\":{\""
		"SelectedItem\":\"AUS\",\"Query\":\"Australia\"},\"addressLine1\":null,\"addressLine2\":null,\"buildingName\":null,\"floorNumber\":null,\"unitNumber\":null,\"subBuildingNumber\":null,\"streetNumber\":\"{AddrStreetNum}\",\"streetName\":\"{AddrStreetName}\",\"streetType\":{\"SelectedItem\":\"{AddrStreetType}\",\"Query\":\"{AddrFullStreetType}\"},\"poBox\":null,\"suburb\":\"{AddrSuburb}\",\"state\":{\"SelectedItem\":\"{AddrState}\",\"Query\":\"{AddrState}\"},\"ruralDelivery\":null,\"city\":null,\"province\":null,\"postCode\":\"{AddrPostCode}\",\"dpid\":\"{DPID_DID}\",\"barcode\""
		":\"{BarCode}\",\"isInternational\":false},\"isItPoBox\":false},\"postalAndResidentialAreSame\":true},\"editLocked\":null,\"externallyMaintainedAddress\":null}},\"furtherQuestions\":{\"taxFileNumber\":{\"hasTaxFileNumber\":null,\"ok\":null},\"foreignTaxResident\":{\"attempts\":0,\"addressFDN\":\"applicants.0.personalDetails.address\",\"crsStatus\":null,\"addresses\":[\"{Address_PartialAddress}\",\"{Address_PartialAddress}\"],\"countries"
		"\":[\"AUS\",\"AUS\"],\"entityType\":\"individual\",\"isForeignTaxResident\":null},\"reasonablenessOutcome\":{\"ok\":null},\"amlQuestions\":{\"primarySourceOfWealth\":{\"SelectedItem\":null,\"Query\":null},\"sourceOfFundsForAccount\":{\"SelectedItem\":null,\"Query\":null},\"reasonForOpeningAccount\":{\"SelectedItem\":null,\"Query\":null}}},\"identityCheck\":{\"identity\":{\"greenIdIdentityCheck\":{\"verificationId\":null,\"verificationStatus\":null},\"creditHeaderCheckbox\":null}}}],\""
		"accountDetails\":{\"preferences\":{},\"declarations\":{\"lastStep\":{\"privacyDeclaration\":null,\"acceptTandCsDeclaration\":null,\"acceptCRSDeclaration\":null}}},\"review\":{},\"personalOrSoleTrader\":{\"accountType\":\"personal\"}}", 
		LAST);

	lr_end_transaction("BP01_T11_EnterContactDetails_OK",LR_AUTO);

	lr_think_time(n);	
	
	return 0;
}
