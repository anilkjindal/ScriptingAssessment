AMPHomePage()
{
	
	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	web_cache_cleanup();
	
	
	//************Launch AMP Web Portal Home Page****************

	web_add_auto_header("DNT", "1");
	web_add_header("Upgrade-Insecure-Requests", "1");	
	
	web_reg_find("Text=Banking, Super, Retirement, Financial Advice &amp; Insurance - AMP", LAST);

	lr_start_transaction("BP01_T01_Load_AMP_HomePage");	

	web_url("{URL}", 
		"URL=http://{URL}/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_end_transaction("BP01_T01_Load_AMP_HomePage",LR_AUTO);

	lr_think_time(n);	
	
	
	return 0;
}
